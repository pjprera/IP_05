﻿class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("cual es el monto de su compra");
        string monto = Console.ReadLine();
        double imonto;
        double descuento = 0.0;
        double preciodes = 0.0; 
        while (!double.TryParse(monto, out imonto))
        {
            Console.WriteLine("monto incorrecto");
            monto = Console.ReadLine();
        }
        
        if (imonto  == 0)
        {
            Console.WriteLine("no tiene descuento");
        
        
        }
        else if (imonto >= 400 )
        {
            if (imonto <= 1000)
            {
                descuento = imonto * 0.07;
                Console.WriteLine("su descuento es de: " + descuento);
                preciodes = imonto - descuento;
                Console.WriteLine(" el total a pagar con el descuento es de: " + preciodes);

            }
            else if (imonto <= 5000)
            {
                descuento = imonto * 0.10;
                Console.WriteLine("su descuento es de: " + descuento);
                preciodes = imonto - descuento;
                Console.WriteLine(" el total a pagar con el descuento es de: " + preciodes);

            }
            else if (imonto <= 15000)
            {
                descuento = imonto * 0.15;
                Console.WriteLine("su descuento es de: " + descuento);
                preciodes = imonto - descuento;
                Console.WriteLine(" el total a pagar con el descuento es de: " + preciodes);
            }
            else
            {
                descuento = imonto * 0.25;
                Console.WriteLine("su descuento es de: " + descuento);
                preciodes = imonto - descuento;
                Console.WriteLine(" el total a pagar con el descuento es de: " + preciodes);

            }
        }

        
        Console.WriteLine("si tienes un codigo de descuento puedes escribirlo: ");
        string codigod = Console.ReadLine();
        int descuencod;
        int.TryParse(codigod, out descuencod);
        double descod;
        double codigodescuento;
        if (descuencod == 12)
        {
            descod = preciodes * 0.05;
            Console.WriteLine(" obtuvo un descuento de: " + descod);
            codigodescuento = preciodes - descod;

            Console.WriteLine("con su codigo de descuento el total a pagar es de: " + codigodescuento);
        }
        
        else
        {
            Console.WriteLine("gracias por su compra");
        }





    }






}