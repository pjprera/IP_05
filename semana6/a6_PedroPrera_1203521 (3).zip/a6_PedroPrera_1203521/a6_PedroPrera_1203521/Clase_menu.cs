﻿class Clase_menu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Programa de control en una obra de construccion");
        Console.WriteLine("seleccione opcion");
        Console.WriteLine("menu de control");
        Console.WriteLine("1. tiempo restante");
        Console.WriteLine("2. cantidad de material");
        Console.WriteLine("3. problemas");
        Console.WriteLine("4. avances");
        string opcion = Console.ReadLine();
        switch (opcion)
        {
            case "1":
                Console.WriteLine("selecciono opcion: " + opcion + "tiempo restante");
                break;
            case "2":
                Console.WriteLine("selecciono opcion: " + opcion + "cantidad de material");
                break;
            case "3":
                Console.WriteLine("selecciono opcion: " + opcion + "problemas");
                break;
            case "4":
                Console.WriteLine("selecciono opcion: " + opcion + "avances");
                break;
            default:
                Console.WriteLine("selecciono una opcion invalida");
                break;
        }
        
        Console.ReadKey();



    }



}
