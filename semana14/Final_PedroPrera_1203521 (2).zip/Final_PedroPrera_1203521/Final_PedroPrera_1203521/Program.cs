﻿class Program
{
    // crear listas para el ingreso de los datos 
    static List<string> dato1 = new List<string>();
    static List<string> dato2 = new List<string>();
    static List<string> dato3 = new List<string>();
    static List<string> dato4 = new List<string>();
   




    // metodo principal
    static void Main()
    {
        // imprimir el nombre del programa y el menu principal
        Console.WriteLine("Programa de control en una obra de construccion");
        Console.WriteLine("este programa es para llevar un control en una obra de construccion, ya que se pueden ver los avances, problemas, cantidad de mayerial y tiempo restante de una obra de construccion");
        Console.WriteLine("Menú Principal:");
        Console.WriteLine("seleccione opcion");
        Console.WriteLine("menu de control");
        Console.WriteLine("1. Proceso Principal");
        Console.WriteLine("2. Manual de Usuario");
        Console.WriteLine("3. Créditos");
        Console.WriteLine("4. Salir");
        
        // crear una variable para la opcion que escoga el usuario
        string opcion = Console.ReadLine();
        // se hizo un switch para llevar al usuario a la opcion que escogio
        switch (opcion)
        {
            case "1":
                ProcesoPrincipal();
                break;
            case "2":
                ManualDeUsuario();
                break;
            case "3":
                Creditos();
                break;
            case "4":
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("Opción no válida. Intente de nuevo.");
                break;
        }




    }
    // metodo del proceso principal
    static void ProcesoPrincipal()
    {
        // se imprime todo el proceso principal
        Console.WriteLine("Estás en el Proceso Principal.");
        Console.WriteLine("seleccione una opcion");
        Console.WriteLine("1. ingresar datos");
        Console.WriteLine("2. ver datos");
        Console.WriteLine("3. regesar al menu principal");
        Console.WriteLine("4. salir");
        // se guarda la variable del usuario
        string opcion1 = Console.ReadLine();
        // con el switch llevamos al usuario a la opcion que escogio
        switch (opcion1)
        {
            case "1":
                IngresoDeDatos();
                break;
            case "2":
                VerDatos();
                break;
            case "3":
                Main();
                break;
            case "4":
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("Opción no válida. Intente de nuevo.");
                break;
        }




    }
    // metodo de ingreso de datos
    static void IngresoDeDatos()
    {
        // se imprime el menu de ingreso de datos
        Console.WriteLine("esta en ingreso de datos");
        Console.WriteLine("que datos quiere ingresar");
        Console.WriteLine("1. tiempo restante de la obra ");
        Console.WriteLine("2. cantidad de material");
        Console.WriteLine("3. problemas");
        Console.WriteLine("4. avances");
        Console.WriteLine("5. regresar al menu anterior");
        Console.WriteLine("6. regresar al menu principal");
        Console.WriteLine("7. salir");
        // se guarda la variable que escogio el ususario
        string opcion2 = Console.ReadLine();

        // se hace un switch para llevar al ususario a la opcion que escogio
        switch (opcion2)
        {
            case "1":
                Console.Write("Ingrese datos: ");
                string nuevoDato = Console.ReadLine();
                dato1.Add(nuevoDato);
                Console.WriteLine("Dato ingresado correctamente.");
                IngresoDeDatos();
                break;
            case "2":
                Console.Write("Ingrese datos: ");
                string nuevoDato1 = Console.ReadLine();
                dato2.Add(nuevoDato1);
                Console.WriteLine("Dato ingresado correctamente.");
                IngresoDeDatos();
                break;
            case "3":
                Console.Write("Ingrese datos: ");
                string nuevoDato2 = Console.ReadLine();
                dato3.Add(nuevoDato2);
                Console.WriteLine("Dato ingresado correctamente.");
                IngresoDeDatos();
                break;
            case "4":
                Console.Write("Ingrese datos: ");
                string nuevoDato3 = Console.ReadLine();
                dato4.Add(nuevoDato3);
                Console.WriteLine("Dato ingresado correctamente.");
                IngresoDeDatos();
                break;
            case "5":
                ProcesoPrincipal();
                break;
            case "6":
                Main();
                break;
            case "7":
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("Opción no válida. Intente de nuevo.");
                break;
        }






    }

    
    // metodo de ver datos
    static void VerDatos()
    {
        // se imprime el menu de verdatos
        Console.WriteLine("esta en ver datos");
        Console.WriteLine("que datos quiere ver");
        Console.WriteLine("1. tiempo restante de la obra ");
        Console.WriteLine("2. cantidad de material");
        Console.WriteLine("3. problemas");
        Console.WriteLine("4. avances");
        Console.WriteLine("5. regresar al menu anterior");
        Console.WriteLine("6. regresar al menu principal");
        Console.WriteLine("7. salir");
        // se guarda la variable que el usuario escogio
        string opcion3 = Console.ReadLine();
        // se hace un switch para llevar al usuario a la opcion que escogio
        switch (opcion3)
        {
            case "1":
                Console.WriteLine("Datos ingresados:");
                foreach (var dato11 in dato1)
                {
                    Console.WriteLine(dato11);
                }
                VerDatos();
                break;
            case "2":
                Console.WriteLine("Datos ingresados:");
                foreach (var dato12 in dato2)
                {
                    Console.WriteLine(dato12);
                }
                VerDatos();
                break;
            case "3":
                Console.WriteLine("Datos ingresados:");
                foreach (var dato13 in dato3)
                {
                    Console.WriteLine(dato13);
                }
                VerDatos();
                break;
            case "4":
                Console.WriteLine("Datos ingresados:");
                foreach (var dato14 in dato4)
                {
                    Console.WriteLine(dato14);
                }
                VerDatos();
                break;
            case "5":
                ProcesoPrincipal();
                break;
            case "6":
                Main();
                break;
            case "7":
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("Opción no válida. Intente de nuevo.");
                break;








        }
    }
    // metodo de manual de usuario
    static void ManualDeUsuario()
    {
        // se imrpime todo el manual del usuario
        Console.Write("este programa consta de varias opciones las cuales son: tiempo restante, cantidad de material, problemas y " +
                "avances. en el tiempo restante podemos ver cuanto tiempo falta para que la obra de construccion este lista," +
                "en cantidad de material podemos ver cuanto material tenemos disponlibe, en ploblemas podemos ver que problemas " +
                "ocurrieron en el dia y en avances podemos ver que avances vimos en el dia. ");
        Console.Write("en este programa se puede ingresar datos, los cuales el ingeniero tiene que ingresar cada dia y el " +
            "supervisor para tener todas las opciones actulizadas, asi como tambien el propietario de la obra puede solo ver " +
            "los datos acutilizados y todos los avances de su obra.");
        Console.Write("para poder ver todas las opciones que hay de los avances de la casa, primero debe de ir al menu" +
            "principal, y seleccionar proceso principal, despues escoger que opcion desea, si ingresar datos o ver datos");
        Console.Write("proposito del programa" +
            "el proposito de este programa es llevar un contol en cualquier obra de construccion en el cual el ingeniero" +
            "debe de ingesar los datos de la obra de construccion, como el tiempo, cantidad de material, problemas y" +
            "avances de cada dia y el cliente puede ver cuanto falta para que su obra este terminada, el material que tienen" +
            "los problemas que tuvieron y los avances, con el fin de llevar un control, tanto el ingeniero como el " +
            "cliente, ");
        Main();
    }
    //metodo de creditos
    static void Creditos()
    {
        // se imprime los creditos
        Console.WriteLine("nombre del proyecto: programa de control en una obra de construccion");
        Console.WriteLine("fecha de creacion: 24 de octubre del 2023");
        Console.WriteLine("estimado de horas invertidas en crear el programa: 7horas");
        Console.WriteLine("Pedro Prera");
        Console.WriteLine("carne: 1203521");
        Console.WriteLine("carrera: ingenieria civil");
        Main();
    }
}