﻿class program
{
    static void Main(string[] args)
    {
        
        string sNombre, sEdad, sCarrera, sCarne;

        Console.WriteLine("Ingrese nombre: ");
        sNombre = Console.ReadLine();

        Console.WriteLine("Ingrese edad: ");
        sEdad = Console.ReadLine();

        Console.WriteLine("Ingrese carrera: ");
        sCarrera = Console.ReadLine();

        Console.WriteLine("Ingrese Carne: ");
        sCarne = Console.ReadLine();

        Console.WriteLine();
        Console.WriteLine("Mi segundo programa");
        Console.WriteLine("nombre: " + sNombre);
        Console.WriteLine("edad: " + sEdad);
        Console.WriteLine("carrera: " + sCarrera);
        Console.WriteLine("carne: " + sCarne);

        Console.Write("soy " + sNombre + " ,tengo " + sEdad + "años y estudio " + sCarrera);
        Console.Write(", mi numero de carne es: " + sCarne);

        Console.ReadKey();
    }





}
