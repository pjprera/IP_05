﻿class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ingrese su nombre: ");
        string Nombre = Console.ReadLine();

        Console.WriteLine("hola mundo");
        Console.WriteLine("soy " + Nombre);

        /*
         este es un ejemplo de comentario en varias 
        lineas
         
         */

        // este es un ejemplo de comentario en una linea 

        Console.Write("Hola mundo ");
        Console.Write("soy " + Nombre);
        Console.ReadKey();
    }
}