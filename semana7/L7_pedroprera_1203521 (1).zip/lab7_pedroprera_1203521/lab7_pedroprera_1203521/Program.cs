﻿class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ejercicio 1");
        Console.WriteLine("ingrese un numero entero");
        string numero1 = Console.ReadLine();
        int num1;
        int.TryParse(numero1, out num1);
        if (num1 == 0) 
        {
            Console.WriteLine("numero es igual a 0");
        
        }
        else if (num1 > 0) 
        {
            Console.WriteLine("su numero es positivo");
        
        }
        else if (num1 < 0)
        {
            Console.WriteLine("su numero es negativo");
        }
        else  
        {
            Console.WriteLine("ingrese un numero entero");
        }

        

        
        

        Console.WriteLine("ejercicio 2");
        int lunes = 1;
        int martes = 2;
        int miercoles = 3;
        int jueves = 4;
        int viernes = 5;
        int sabado = 6;
        int domingo = 7;
        Console.WriteLine("ingrese un numero del 1 al 7");
        string num = Console.ReadLine();
        int num2;
        int.TryParse(num, out num2);
        if (num2 == 1)
        {
            Console.WriteLine("su numero es: lunes");
        }
        else if (num2 == 2)
        {
            Console.WriteLine("su numero es: martes ");
        }
        else if (num2 == 3)
        {
            Console.WriteLine("su numero es: miercoles");
        }
        else if (num2 == 4)
        {
            Console.WriteLine("su numero es: jueves ");
        }
        else if (num2 == 5)
        {
            Console.WriteLine("su numero es: viernes");
        }
        else if (num2 == 6)
        {
            Console.WriteLine("su numero es: sabado ");
        }
        else if (num2 == 7)
        {
            Console.WriteLine("su numero es: domingo");
        }
        else if (num2 < 7)
        {
            Console.WriteLine("el numero a ingresar debe estar contenido entre 1 y 7");
        }
        else if (num2 > 1)
        {
            Console.WriteLine("el numero a ingresar debe estar contenido entre 1 y 7");
        }
        Console.ReadKey();
    }





}