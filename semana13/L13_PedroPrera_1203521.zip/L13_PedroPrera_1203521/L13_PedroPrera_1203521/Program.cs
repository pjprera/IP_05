﻿class program
{
    static void Main(string[] args)
    {
        double[] arreglo = new double[10];
        Console.WriteLine("ingrese el primer numero");
        arreglo[0] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[1] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[2] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[3] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[4] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[5] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[6] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[7] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[8] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");
        arreglo[9] = int.Parse(Console.ReadLine());
        Console.WriteLine("ingrese el primer numero");

        double minimo = arreglo.Min();
        Console.WriteLine("el numero mas pequeño ingresado es: " + minimo);
        double maximo = arreglo.Max();
        Console.WriteLine("el numero mas grande ingresado es: " + maximo);
        double suma = arreglo.Sum();
        Console.WriteLine("la suma de todos los numeros ingresados es: " + suma);
        Console.WriteLine("estos son los numero ingresados en el arreglo por posicion del 0 al 9: " + arreglo[0] + ", " + arreglo[1] + ", " + arreglo[2] + ", " + arreglo[3] + ", " + arreglo[4] + ", " + arreglo[5] + ", " + arreglo[6] + ", " + arreglo[7] + ", " + arreglo[8] + ", " + arreglo[9]);
        Console.WriteLine("estos son los numeros ingresados en el arreglo del 9 al 0: " + arreglo[9] + ", " + arreglo[8] + ", " + arreglo[7] + ", " + arreglo[6] + ", " + arreglo[5] + ", " + arreglo[4] + ", " + arreglo[3] + ", " + arreglo[2] + ", " + arreglo[1] + ", " + arreglo[0]);
        double promedio = (arreglo[0] + arreglo[1] + arreglo[2] + arreglo[3] + arreglo[4] + arreglo[5] + arreglo[6] + arreglo[7] + arreglo[8] + arreglo[9]) / 10;
        Console.WriteLine("este es el promedio de todos los numeros del arreglo: " + promedio);
        double sumaPares = 0;
        for (int i = 0; i < arreglo.Length; i += 2)
        {
            sumaPares += arreglo[i];
        }
        Console.WriteLine("La suma de posiciones pares es: " + sumaPares);

       
        double sumaImpares = 0;
        for (int i = 1; i < arreglo.Length; i += 2)
        {
            sumaImpares += arreglo[i];
        }
        Console.WriteLine("La suma de posiciones impares es: " + sumaImpares);













    }




}