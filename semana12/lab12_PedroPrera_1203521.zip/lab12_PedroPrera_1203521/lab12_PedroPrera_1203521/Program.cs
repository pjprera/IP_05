﻿class circulo
{

    private double radioA;
    public circulo(double radio)
    {
        radioA = radio;




    }
    private double ObtenerPerimetro()
    {
        double perimetro = 2 * 3.1416 * radioA;
        return perimetro;


    }
    private double ObtenerArea()
    {
        double area = 3.1416 * Math.Pow(radioA, 2);
        return area;



    }
    private double ObtenerVolumen()
    {
        double volumen = (4 * 3.1416 * Math.Pow(radioA, 3)) / 3;
        return volumen;


    }
    public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
    {
        unPerimetro = ObtenerPerimetro();
        unArea = ObtenerArea();
        unVolumen = ObtenerVolumen();


    }
}
class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ingrese el radio del circulo");
        string rad = Console.ReadLine();
        double radio;
        double.TryParse(rad, out radio);
        circulo objCirculo = new circulo(radio);
        double perimetro = 0.0;
        double area = 0.0;
        double volumen = 0.0;
        objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);
        Console.WriteLine("perimetro: " + perimetro);
        Console.WriteLine("area: " + area);
        Console.WriteLine("volumen: " + volumen);










    }





}
    

