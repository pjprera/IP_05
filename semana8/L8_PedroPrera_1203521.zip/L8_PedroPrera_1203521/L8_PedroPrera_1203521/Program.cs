﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Pedro Prera. carne: 1203521");
        Console.WriteLine("Ingrese un numero entre 0 y 999.99: ");
        double num = Convert.ToDouble(Console.ReadLine());

        if (num < 0 || num > 999.99)
        {
            Console.WriteLine(" su numero no esta en el rango");
        }
        else
        {
            Equivalencia(num);
        }
    }

    static void Equivalencia(double num)
    {
        int[] denob = { 100, 50, 20, 10, 5 };
        string[] billetes = { "billetes de 100 quetzales", "billetes de 50 quetzales", "billetes de 20 quetzales", "billetes de 10 quetzales", "billetes de 5 quetzales" };

        double[] denoc = { 1, 0.25, 0.01 };
        string[] monedas = { "moneda de 1 quetzal", "moneda de 25 centavos", " moneda de 1 centavo" };

        Console.WriteLine("Equivalencia en billetes:");

        for (int i = 0; i < denob.Length; i++)
        {
            int cantb = (int)(num / denob[i]);
            if (cantb > 0)
            {
                Console.WriteLine($"{cantb} {billetes[i]}");
                num -= cantb * denob[i];
            }
        }

        Console.WriteLine("Equivalencia en monedas:");

        for (int i = 0; i < denoc.Length; i++)
        {
            int cantm = (int)(num / denoc[i]);
            if (cantm > 0)
            {
               
                Console.WriteLine($"{cantm} {monedas[i]}");
                num -= cantm * denoc[i];
            }
        }
        Console.ReadKey();
    } 

    
}
