﻿class Program
{
    static void Main()
    {
        Console.WriteLine("Programa de control en una obra de construccion");
        Console.WriteLine("este programa es para llevar un control en una obra de construccion, ya que se pueden ver los avances, problemas, cantidad de mayerial y tiempo restante de una obra de construccion");
        Console.WriteLine("Menú Principal:");
        Console.WriteLine("seleccione opcion");
        Console.WriteLine("menu de control");
        Console.WriteLine("1. Proceso Principal");
        Console.WriteLine("2. Manual de Usuario");
        Console.WriteLine("3. Créditos");
        Console.WriteLine("4. Salir");
        

        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                ProcesoPrincipal();
                break;
            case "2":
                ManualDeUsuario();
                break;
            case "3":
                Creditos();
                break;
            case "4":
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("Opción no válida. Intente de nuevo.");
                break;
        }




    }

    static void ProcesoPrincipal()
    {
        Console.WriteLine("Estás en el Proceso Principal.");
        Main();
        
    }

    static void ManualDeUsuario()
    {
        Console.Write("este programa consta de varias opciones las cuales son: tiempo restante, cantidad de materia, problemas y " +
                "avances. en el tiempo restante podemos ver caunto tiempo falta para que la obra de construccion este lista," +
                "en cantidad de material podemos ver cuanto material tenemos disponlibe, en ploblemas podemos ver que problemas " +
                "ocurrieron en el dia y en avances podemos ver que avances vimos en el dia. ");
        Console.Write("en este programa se puede ingresar datos, los cuales el ingeniero tiene que ingresar cada dia y el " +
            "supervisor para tener todas las opciones actulizadas, asi como tambien el propietario de la obra puede solo ver " +
            "los datos acutilizados y todos los avances de su obra.");
        Console.Write("para poder ver todas las opciones que hay de los avances de la casa, primero debe de ir al menu" +
            "principal, y seleccionar proceso principal, despues escoger que opcion desea visualizar");
        Console.Write("proposito del programa" +
            "el proposito de este programa es llevar un contol en cualquier obra de construccion en el cual el ingeniero" +
            "debe de ingesar los datos de la obra de construccion, como el tiempo, cantidad de material, problemas y" +
            "avances de cada dia y el cliente puede ver cuanto falta para que su obra este terminada, el material que tienen" +
            "los problemas que tuvieron y los avances, con el fin de llevar un control, tanto el ingeniero como el " +
            "cliente, ");
        Main();
    }

    static void Creditos()
    {
        Console.WriteLine("nombre del proyecto: programa de control en una obra de construccion");
        Console.WriteLine("fecha de creacion: 24 de octuble del 2023");
        Console.WriteLine("estimado de horas invertidas en crear el programa: 7horas");
        Console.WriteLine("Pedro Prera");
        Console.WriteLine("carne: 1203521");
        Console.WriteLine("carrera: ingenieria civil");
        Main();
    }
}